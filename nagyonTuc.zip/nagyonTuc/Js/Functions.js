        
    function save() {
        localStorage.setItem("romanCounter", romanCounter);
        localStorage.setItem("autoClick", autoClick);
        localStorage.setItem("farms", farms);
        localStorage.setItem("multiplier", multiplier);
    }
    function load() {
        romanCounter = localStorage.getItem("romanCounter");
        romanCounter = parseInt(romanCounter);
        autoClick = localStorage.getItem("autoClick");
        autoClick = parseInt(autoClick);
        farms = localStorage.getItem("farms");
        farms = parseInt(farms);
        multiplier = localStorage.getItem("multiplier");
        multiplier = parseInt(multiplier);        
        update()
    }

    function add() {
        romanCounter = romanCounter + 1;
        update()
    }
 
    function buyAutoClick() {
        if (romanCounter >= ((autoClick+1) * 24)) {
            romanCounter = romanCounter - ((autoClick+1) * 24);
            autoClick = autoClick + 1;
            document.getElementById('romanPerSec').innerHTML = (((autoClick)+(farms*2))*multiplier) + " Darabot Románoznak A Kutyáid Másodpercenként";

            update()
        }
        alert("Nincs Elég Tekintélyed Kutyákat Fogadni");
    }
 
    function buyFarm() {
        if (romanCounter >= ((farms+1) * 15)) {
            romanCounter = romanCounter - ((farms+1) * 15);
            farms = farms + 1;
            update()
        }
    }
 
    function buyMultiplier() {
        if (romanCounter >= ((multiplier+1) * 111150)) {
            romanCounter = romanCounter - ((multiplier+1) * 111150);
            multiplier = multiplier + 1;
            update()
        }
        alert("Majd Próbáld Meg Ha Már Tuc")
    }