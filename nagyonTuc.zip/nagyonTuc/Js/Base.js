function update() {
    document.getElementById('text').value = romanCounter;
    document.title = romanCounter + " Románozás";

    document.getElementById('ammountMultiplier').innerHTML = "Románozási Erőnövelés: " + (multiplier+1);
    document.getElementById('ammountMultiplier2').innerHTML = "x" + (multiplier+1);
    document.getElementById('costMultiplier').innerHTML = ((multiplier+1) * 111150) + " Románozás";
    document.getElementById('costMultiplierGap').innerHTML = (((multiplier+1) * 111150) - romanCounter)+ " Kell Még Te Gedvány";

    document.getElementById('currentMultiplier').innerHTML = "Jelenlegi Románozásod Ereje " + (multiplier);

    document.getElementById('ammountAutoClick').innerHTML = "Ennyi Kutyád Próbál Románozni Éppen: " + autoClick;
    document.getElementById('costAutoClick').innerHTML = ((autoClick+1) * 24) + " Románozás";

    document.getElementById('ammountFarms').innerHTML = "" + farms + " Romantelep";
    document.getElementById('costFarms').innerHTML = ((farms+1) * 15) + " romans";
}

var multiplier = 1;
var romanCounter = 0;
var autoClick = 0;
var farms = 0;

function timer() {
    romanCounter = romanCounter + autoClick*multiplier;
    romanCounter = romanCounter + farms*2*multiplier;
    update()
}
setInterval(timer, 1000)